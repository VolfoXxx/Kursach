﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql;
using MySql.Data;
using System.Data;

namespace Kursovaya_Beloipeckiy
{
    /// <summary>
    /// Логика взаимодействия для CSSwind.xaml
    /// </summary>
    public partial class CSSwind : Window
    {
        MainWindow mnWind = new MainWindow();
        Class cl = new Class();
        DataTable da;

        SolidColorBrush BRfr = new SolidColorBrush(Color.FromRgb(232, 232, 232));
        SolidColorBrush BRbcg = new SolidColorBrush(Color.FromRgb(0, 178, 238));
        SolidColorBrush BRbrd = new SolidColorBrush(Color.FromRgb(0, 154, 205));

        string[] text = new string[1];

        void Update() => da = cl.GetPages();

        public CSSwind()
        {
            InitializeComponent();
            //for(int i = 0; i < 1; i++)

            Update();

            for (int i = 0; i < da.Rows.Count; i++)
            {
                Array.Resize(ref text, i + 1);
                CreateButton(da.Rows[i].Field<string>(1));
                
            }
            
            //CreateButton(da.Rows[1].Field<string>(1));

            for (int i = 0; i < da.Rows.Count; i++)
            {
                Array.Resize(ref text, i + 1);
                text[i] = da.Rows[i].Field<string>(2);
                
            }
            
        }

        void CreateButton(string name = "CSS")
        {
            Button btn = new Button();
            btn.Content = name;
            btn.FontSize = 16;
            btn.Foreground = BRfr;
            btn.Width = 171;
            btn.Height = 30;
            btn.Background = BRbcg;
            btn.BorderBrush = BRbrd;
            btn.Tag = Lv_css.Items.Count + 1 + "";
            btn.Click += DoSmth;
            Lv_css.Items.Add(btn);
        }

        void DoSmth(object sender, RoutedEventArgs e)
        {
            object tag = ((Button)e.OriginalSource).Tag;

            lb.Content = text[Int32.Parse((string)tag) - 1];
        }

        private void btn_back_Click(object sender, RoutedEventArgs e)
        {
            mnWind.Show();
            this.Close();
        }
    }
}
