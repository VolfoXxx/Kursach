﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;

namespace Kursovaya_Beloipeckiy
{
    class Class
    {

        MySqlConnection connection;
        MySqlConnectionStringBuilder connectionString;

        public Class()
        {
            connectionString = new MySqlConnectionStringBuilder();
            connectionString.Server = "localhost";
            connectionString.Database = "css_helper";
            connectionString.UserID = "root";
            connectionString.Password = "k403";
        }

        public DataTable GetPages()
        {
            connection = new MySqlConnection(connectionString.ConnectionString);
            connection.Open();
            MySqlDataAdapter cndText = new MySqlDataAdapter("select * from page", connection);
            DataTable dt = new DataTable();
            cndText.Fill(dt);
            connection.Close();
            return dt;
        }
    }
}
